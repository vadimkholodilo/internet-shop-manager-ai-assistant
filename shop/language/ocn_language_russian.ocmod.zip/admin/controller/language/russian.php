<?php
namespace Opencart\Admin\Controller\Extension\OcnLanguageRussian\Language;
class Russian extends \Opencart\System\Engine\Controller
{
	public function index(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=language')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/ocn_language_russian/language/russian', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/ocn_language_russian/language/russian.save', 'user_token=' . $this->session->data['user_token']);
		$data['english'] = $this->url->link('extension/ocn_language_russian/language/russian.english', 'user_token=' . $this->session->data['user_token']);
		$data['translate'] = $this->url->link('extension/ocn_language_russian/language/russian.translate', 'user_token=' . $this->session->data['user_token']);
		$data['check'] = $this->url->link('extension/ocn_language_russian/language/russian.check', 'user_token=' . $this->session->data['user_token']);
		$data['compare'] = $this->url->link('extension/ocn_language_russian/language/russian.compare', 'user_token=' . $this->session->data['user_token']);
		$data['upgrade'] = $this->url->link('extension/ocn_language_russian/language/russian.upgrade', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=language');

		$data['language_russian_status'] = $this->config->get('language_russian_status');
		$data['extension_version'] = $this->extensionVersion();
		$data['extension_links'] = $this->extensionLinks();

		$this->load->model('localisation/language');

		$data['english_installed'] = (bool)$this->model_localisation_language->getLanguageByCode('en-gb');

		$state = $this->presetFormState();

		$data['preset_active'] = $state['active'];
		$data['preset_selected'] = $state['selected'];
		$data['preset_zone_id'] = $state['zone_id'];
		$data['zones'] = $state['zones'];
		$data['preset_zone_ids'] = $state['preset_zone_ids'];

		$data['presets'] = [];

		foreach ($this->presets() as $code => $preset) {
			$data['presets'][] = [
				'code' => $code,
				'name' => $this->language->get($preset['label'])
			];
		}

		$translation = $this->translationView();

		$data['translation_groups'] = $translation['groups'];
		$data['translation_all'] = $translation['all'];
		$data['translation_error'] = $translation['error'];

		$data['seo'] = $this->url->link('extension/ocn_language_russian/language/russian.seo', 'user_token=' . $this->session->data['user_token']);

		$seo = $this->seoView();

		$data['seo_rows'] = $seo['rows'];
		$data['seo_error'] = $seo['error'];
		$data['seo_multi_store'] = $seo['multi_store'];

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/ocn_language_russian/language/russian', $data));
	}

	public function save(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$apply = $this->requestedDefaults();
		$preset = (string)($this->request->post['language_russian_preset'] ?? '');
		$values = [];

		if ($preset !== '' && !isset($this->presets()[$preset])) {
			$json['error'] = $this->language->get('error_preset');
		}

		if (!$json && in_array(true, $apply, true)) {
			$resolved = $this->resolvePreset($preset, $apply);

			if ($resolved['error']) {
				$json['error'] = $resolved['error'];
			} else {
				$values = $resolved['values'];
			}
		}

		if (!$json) {
			$setting = $this->request->post;
			$setting['language_russian_preset'] = isset($this->presets()[$preset]) ? $preset : '';
			$setting['language_russian_zone_id'] = $this->storedZoneId();

			foreach (array_keys($apply) as $key) {
				unset($setting['language_russian_default_' . $key]);
			}

			$this->saveLanguageSetting($setting);

			foreach ($values as $key => $value) {
				$this->writeConfigValue($key, $value);
			}

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function english(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$import = !empty($this->request->post['import']);
		$sql = '';

		if (!$json) {
			$this->load->model('localisation/language');

			$english = $this->model_localisation_language->getLanguageByCode('en-gb');

			if ($english && !$import) {
				$json['error'] = $this->language->get('error_english_import');
			}
		}

		if (!$json && $import) {
			$path = $this->englishInstallSqlPath();
			$loaded = is_file($path) ? file_get_contents($path) : false;

			if (!is_string($loaded) || $loaded === '') {
				$json['error'] = $this->language->get('error_english_sql');
			} else {
				$sql = $loaded;
			}
		}

		$locked = false;

		if (!$json) {
			$lock = $this->db->query("SELECT GET_LOCK('ocn_language_en_gb', 30) AS `locked`");
			$locked = (int)($lock->row['locked'] ?? 0) === 1;

			if (!$locked) {
				$json['error'] = $this->language->get('error_english');
			}
		}

		if (!$json) {
			$started = false;

			try {
				$this->db->query('START TRANSACTION');
				$started = true;

				$english = $this->model_localisation_language->getLanguageByCode('en-gb');
				$created = false;

				if ($english) {
					if (!$import) {
						throw new \RuntimeException('import');
					}

					$language_id = (int)$english['language_id'];
				} else {
					$language_id = $this->createEnglishLanguage();
					$created = true;
				}

				if ($import) {
					$russian_id = $this->russianLanguageId();

					if ($russian_id && $language_id === $russian_id) {
						throw new \RuntimeException('russian');
					}

					$this->replaceEnglishDescriptions($sql, $language_id);
				}

				$this->db->query('COMMIT');
				$started = false;
				$this->clearEnglishCaches();

				if ($created && !$import) {
					$json['success'] = $this->language->get('text_english_created');
				} elseif ($created) {
					$json['success'] = $this->language->get('text_english_success');
				} else {
					$json['success'] = $this->language->get('text_english_descriptions_success');
				}

				$json['installed'] = true;
				$json['created'] = $created;
			} catch (\Throwable $exception) {
				if ($started) {
					try {
						$this->db->query('ROLLBACK');
					} catch (\Throwable $ignored) {
					}
				}

				$code = $exception->getMessage();

				if ($code === 'missing') {
					$json['error'] = $this->language->get('error_english_sql');
				} elseif ($code === 'taken') {
					$json['error'] = $this->language->get('error_english_id');
				} elseif ($code === 'import') {
					$json['error'] = $this->language->get('error_english_import');
				} else {
					$json['error'] = $this->language->get('error_english');
				}
			} finally {
				if ($locked) {
					$this->db->query("SELECT RELEASE_LOCK('ocn_language_en_gb')");
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	private function englishInstallSqlPath(): string
	{
		return DIR_OPENCART . 'install/opencart-en-gb.sql';
	}

	/**
	 * Inserts English as language_id 1 with an empty extension.
	 * addLanguage() is not used: it would copy the current language descriptions
	 * and take the next autoincrement id. The install SQL is not read here.
	 *
	 * @throws \RuntimeException
	 */
	private function createEnglishLanguage(): int
	{
		$taken = $this->db->query("SELECT `code` FROM `" . DB_PREFIX . "language` WHERE `language_id` = '1' LIMIT 1");

		if ($taken->num_rows) {
			throw new \RuntimeException('taken');
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "language` SET `language_id` = '1', `name` = 'English', `code` = 'en-gb', `locale` = 'en-gb,en', `extension` = '', `sort_order` = '1', `status` = '1'");

		return 1;
	}

	/**
	 * Replace description rows of the English language with language_id 1 from the install SQL.
	 * Rows of any other language, including Russian language_id 2, stay as they are.
	 *
	 * @throws \RuntimeException
	 */
	private function replaceEnglishDescriptions(string $sql, int $language_id): void
	{
		if ($language_id < 1) {
			throw new \RuntimeException('sql');
		}

		$grouped = [];

		foreach ($this->sqlInserts($sql) as $insert) {
			if ($insert['table'] === 'language' || !preg_match('/^[a-z0-9_]+$/', $insert['table'])) {
				continue;
			}

			$lang_index = array_search('language_id', $insert['columns'], true);

			if ($lang_index === false) {
				continue;
			}

			$meta = $this->englishTableMeta($insert['table']);

			if (!$meta['columns'] || !isset($meta['columns']['language_id'])) {
				throw new \RuntimeException('sql');
			}

			$keep = [];

			foreach ($insert['columns'] as $index => $column) {
				if (!isset($meta['columns'][$column])) {
					continue;
				}

				if (!$meta['language_in_primary'] && isset($meta['auto'][$column])) {
					continue;
				}

				$keep[] = $index;
			}

			if (!in_array($lang_index, $keep, true)) {
				throw new \RuntimeException('sql');
			}

			$columns = [];

			foreach ($keep as $index) {
				$columns[] = $insert['columns'][$index];
			}

			$signature = implode("\0", $columns);

			if (!isset($grouped[$insert['table']][$signature])) {
				$grouped[$insert['table']][$signature] = [
					'columns' => $columns,
					'rows' => []
				];
			}

			foreach ($insert['rows'] as $row) {
				if (count($row) !== count($insert['columns']) || trim((string)$row[$lang_index]) !== '1') {
					if (count($row) !== count($insert['columns'])) {
						throw new \RuntimeException('sql');
					}

					continue;
				}

				$values = [];

				foreach ($keep as $index) {
					$token = (string)$row[$index];

					if ($index === $lang_index) {
						$token = (string)$language_id;
					}

					if (!$this->sqlTokenAllowed($token)) {
						throw new \RuntimeException('sql');
					}

					$values[] = $token;
				}

				$grouped[$insert['table']][$signature]['rows'][] = $values;
			}
		}

		$written = false;

		foreach ($grouped as $table => $signatures) {
			$pending = [];

			foreach ($signatures as $group) {
				if ($group['rows']) {
					$pending[] = $group;
				}
			}

			if (!$pending) {
				continue;
			}

			$this->db->query("DELETE FROM `" . DB_PREFIX . $table . "` WHERE `language_id` = '" . (int)$language_id . "'");

			foreach ($pending as $group) {
				$this->insertEnglishRows($table, $group['columns'], $group['rows']);
			}

			$written = true;
		}

		if (!$written) {
			throw new \RuntimeException('sql');
		}
	}

	/**
	 * @param array<int, string> $columns
	 * @param array<int, array<int, string>> $rows
	 */
	private function insertEnglishRows(string $table, array $columns, array $rows): void
	{
		foreach ($columns as $column) {
			if (!preg_match('/^[a-z0-9_]+$/', $column)) {
				throw new \RuntimeException('sql');
			}
		}

		$column_sql = '`' . implode('`, `', $columns) . '`';
		$chunk = [];
		$size = 0;

		foreach ($rows as $row) {
			$tuple = '(' . implode(', ', $row) . ')';
			$chunk[] = $tuple;
			$size += strlen($tuple);

			if (count($chunk) >= 40 || $size >= 200000) {
				$this->db->query("INSERT INTO `" . DB_PREFIX . $table . "` (" . $column_sql . ") VALUES " . implode(",\n", $chunk));
				$chunk = [];
				$size = 0;
			}
		}

		if ($chunk) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . $table . "` (" . $column_sql . ") VALUES " . implode(",\n", $chunk));
		}
	}

	/**
	 * @return array{columns: array<string, bool>, auto: array<string, bool>, language_in_primary: bool}
	 */
	private function englishTableMeta(string $table): array
	{
		static $cache = [];

		if (isset($cache[$table])) {
			return $cache[$table];
		}

		$name = DB_PREFIX . $table;
		$columns = $this->db->query("SELECT `COLUMN_NAME` AS `name`, `EXTRA` AS `extra` FROM `information_schema`.`COLUMNS` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = '" . $this->db->escape($name) . "'");
		$primary = $this->db->query("SELECT `COLUMN_NAME` AS `name` FROM `information_schema`.`STATISTICS` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = '" . $this->db->escape($name) . "' AND `INDEX_NAME` = 'PRIMARY'");

		$meta = [
			'columns' => [],
			'auto' => [],
			'language_in_primary' => false
		];

		foreach ($columns->rows as $column) {
			$column_name = (string)$column['name'];
			$meta['columns'][$column_name] = true;

			if (stripos((string)$column['extra'], 'auto_increment') !== false) {
				$meta['auto'][$column_name] = true;
			}
		}

		foreach ($primary->rows as $column) {
			if ((string)$column['name'] === 'language_id') {
				$meta['language_in_primary'] = true;
			}
		}

		$cache[$table] = $meta;

		return $meta;
	}

	private function sqlTokenAllowed(string $token): bool
	{
		if ($token !== '' && $token[0] === "'") {
			return str_ends_with($token, "'");
		}

		return $token === 'NULL' || (bool)preg_match('/^-?\d+(?:\.\d+)?$/', $token);
	}

	/**
	 * @return array<int, array{table: string, columns: array<int, string>, rows: array<int, array<int, string>>}>
	 */
	private function sqlInserts(string $sql): array
	{
		$inserts = [];
		$length = strlen($sql);
		$offset = 0;

		while (($start = strpos($sql, 'INSERT INTO `', $offset)) !== false) {
			if (!preg_match('/\GINSERT INTO `oc_([a-z0-9_]+)` \(([^)]+)\)\s*VALUES\s*/A', $sql, $match, 0, $start)) {
				$offset = $start + 12;
				continue;
			}

			$columns = array_map(static function (string $column): string {
				return trim($column, " `\t\r\n");
			}, explode(',', $match[2]));
			$pos = $start + strlen($match[0]);
			$rows = [];

			while ($pos < $length) {
				while ($pos < $length && ctype_space($sql[$pos])) {
					$pos++;
				}

				if ($pos >= $length || $sql[$pos] !== '(') {
					break;
				}

				$pos++;
				$values = [];

				while ($pos < $length) {
					while ($pos < $length && ctype_space($sql[$pos])) {
						$pos++;
					}

					$token = $this->readSqlValue($sql, $pos);

					if ($token === null) {
						throw new \RuntimeException('sql');
					}

					$values[] = $token;

					while ($pos < $length && ctype_space($sql[$pos])) {
						$pos++;
					}

					if ($pos < $length && $sql[$pos] === ',') {
						$pos++;
						continue;
					}

					if ($pos < $length && $sql[$pos] === ')') {
						$pos++;
						break;
					}

					throw new \RuntimeException('sql');
				}

				if (count($values) !== count($columns)) {
					throw new \RuntimeException('sql');
				}

				$rows[] = $values;

				while ($pos < $length && ctype_space($sql[$pos])) {
					$pos++;
				}

				if ($pos < $length && $sql[$pos] === ',') {
					$pos++;
					continue;
				}

				if ($pos < $length && $sql[$pos] === ';') {
					$pos++;
					break;
				}

				throw new \RuntimeException('sql');
			}

			$inserts[] = [
				'table' => $match[1],
				'columns' => $columns,
				'rows' => $rows
			];
			$offset = $pos;
		}

		return $inserts;
	}

	private function readSqlValue(string $sql, int &$pos): ?string
	{
		$length = strlen($sql);

		if ($pos >= $length) {
			return null;
		}

		if ($sql[$pos] === "'") {
			$start = $pos;
			$pos++;

			while ($pos < $length) {
				if ($sql[$pos] === '\\') {
					$pos += 2;
					continue;
				}

				if ($sql[$pos] === "'") {
					if (($sql[$pos + 1] ?? '') === "'") {
						$pos += 2;
						continue;
					}

					$pos++;

					return substr($sql, $start, $pos - $start);
				}

				$pos++;
			}

			return null;
		}

		$start = $pos;
		$depth = 0;

		while ($pos < $length) {
			$char = $sql[$pos];

			if ($char === "'") {
				if ($this->readSqlValue($sql, $pos) === null) {
					return null;
				}

				continue;
			}

			if ($char === '(') {
				$depth++;
				$pos++;
				continue;
			}

			if ($char === ')') {
				if ($depth === 0) {
					break;
				}

				$depth--;
				$pos++;
				continue;
			}

			if ($char === ',' && $depth === 0) {
				break;
			}

			$pos++;
		}

		if ($pos === $start) {
			return null;
		}

		return trim(substr($sql, $start, $pos - $start));
	}

	private function clearEnglishCaches(): void
	{
		foreach (['language', 'country', 'zone', 'length_class', 'weight_class', 'stock_status', 'order_status', 'return_status', 'return_action', 'return_reason', 'subscription_status', 'customer_group', 'category', 'product', 'information', 'manufacturer', 'option', 'banner', 'seo_url'] as $key) {
			$this->cache->delete($key);
		}
	}

	public function check(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('access', 'extension/ocn_language_russian/language/russian') && !$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$repo = $this->githubRepo();

			if ($repo === null) {
				$json['error'] = $this->language->get('error_update_link');
			}
		}

		if (!$json) {
			$remote = $this->latestGithubRelease($repo);

			if ($remote === null) {
				$json['error'] = $this->language->get('error_update');
			} else {
				$local = $this->extensionVersion();
				$json['version'] = $remote['version'];
				$json['url'] = $remote['url'];
				$json['kind'] = $remote['kind'];

				if ($this->compareVersions($remote['version'], $local) > 0) {
					$json['newer'] = true;
					$json['message'] = sprintf($this->language->get($remote['kind'] === 'tag' ? 'text_update_tag' : 'text_update_available'), $remote['version']);
				} else {
					$json['newer'] = false;
					$json['message'] = $this->language->get('text_update_current');
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function compare(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('access', 'extension/ocn_language_russian/language/russian') && !$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$diff = $this->packageDiff();
			$remote = $diff['remote'];

			if ($remote !== null) {
				$json['version'] = $remote['version'];
				$json['url'] = $remote['url'];
				$json['kind'] = $remote['kind'];
				$json['newer'] = $diff['newer'];
				$json['message'] = $diff['newer']
					? sprintf($this->language->get($remote['kind'] === 'tag' ? 'text_update_tag' : 'text_update_available'), $remote['version'])
					: $this->language->get('text_update_current');
			}

			if ($diff['error'] !== '') {
				$json['error'] = $diff['error'];
			} elseif (!$diff['newer']) {
				$json['newer'] = false;
				$json['files_message'] = $this->language->get('text_update_not_newer');
			} else {
				$json['changed'] = $diff['changed'];
				$json['added'] = $diff['added'];
				$json['removed'] = $diff['removed'];

				if (!$diff['changed'] && !$diff['added'] && !$diff['removed']) {
					$json['files_message'] = $this->language->get('text_update_same');
				}
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function upgrade(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$diff = null;

		if (!$json) {
			$diff = $this->packageDiff();

			if ($diff['error'] !== '') {
				$json['error'] = $diff['error'];
			} elseif (!$diff['newer'] || $diff['remote'] === null) {
				$json['error'] = $this->language->get('text_update_not_newer');
			} elseif (!$diff['changed'] && !$diff['added'] && !$diff['removed']) {
				$json['error'] = $this->language->get('text_update_same');
			}
		}

		if (!$json && $diff !== null) {
			$written = $this->applyPackageDiff($diff);

			if ($written['error'] !== '') {
				$json['error'] = $written['error'];
			} else {
				$json['success'] = sprintf($this->language->get('text_upgrade_success'), (string)count($diff['changed']), (string)count($diff['added']), (string)count($diff['removed']));
				$json['version'] = $this->extensionVersion();
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function translate(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$language_id = $this->russianLanguageId();

		if (!$json && !$language_id) {
			$json['error'] = $this->language->get('error_translation_language');
		}

		$selected = $this->request->post['selected'] ?? [];
		$names = $this->request->post['name'] ?? [];
		$extras = $this->request->post['extra'] ?? [];

		if (!$json && (!is_array($selected) || !$selected)) {
			$json['error'] = $this->language->get('error_translation');
		}

		$updated = [];
		$caches = [];

		if (!$json) {
			foreach ($selected as $key) {
				$key = (string)$key;
				$parts = explode(':', $key, 2);

				if (count($parts) !== 2 || $parts[0] === '' || $parts[1] === '') {
					continue;
				}

				$name = trim((string)($names[$key] ?? ''));
				$extra = trim((string)($extras[$key] ?? ''));
				$row = $this->writeTranslation($parts[0], $parts[1], $name, $extra, $language_id);

				if (!$row) {
					continue;
				}

				$updated[] = $row;
				$caches[$parts[0]] = true;
			}

			if (!$updated) {
				$json['error'] = $this->language->get('error_translation');
			} else {
				foreach (array_keys($caches) as $type) {
					$cache = $this->translationCacheKey($type);

					if ($cache !== '') {
						$this->cache->delete($cache);
					}
				}

				$json['success'] = $this->language->get('text_translation_success');
				$json['rows'] = $updated;
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function seo(): void
	{
		$this->load->language('extension/ocn_language_russian/language/russian');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/ocn_language_russian/language/russian')) {
			$json['error'] = $this->language->get('error_permission');
		}

		$language_id = $this->russianLanguageId();

		if (!$json && !$language_id) {
			$json['error'] = $this->language->get('error_seo_language');
		}

		$selected = $this->request->post['selected'] ?? [];
		$keywords = $this->request->post['keyword'] ?? [];

		if (!$json && (!is_array($selected) || !$selected)) {
			$json['error'] = $this->language->get('error_seo');
		}

		$plan = [];

		if (!$json && !is_array($keywords)) {
			$json['error'] = $this->language->get('error_seo');
		}

		if (!$json) {
			$pages = $this->seoPages();

			foreach ($selected as $token) {
				$item = $this->seoPlanItem((string)$token, $pages, $keywords);

				if ($item === null) {
					continue;
				}

				if ($item['error'] !== '') {
					$json['error'] = $item['error'];
					$plan = [];
					break;
				}

				$plan[] = $item;
			}

			if (!$json && !$plan) {
				$json['error'] = $this->language->get('error_seo');
			}
		}

		if (!$json) {
			$this->load->model('design/seo_url');

			$pending = [];
			$written = [];
			$used = [];

			foreach ($plan as $item) {
				$current = $this->russianSeoKeyword($item['key'], $item['value'], $item['store_id'], $language_id);

				if ($current !== '') {
					$written[] = [
						'key' => $item['token'],
						'current' => $current,
						'skipped' => true
					];
					continue;
				}

				$slot = $item['store_id'] . "\0" . oc_strtolower($item['keyword']);

				if (isset($used[$slot])) {
					$json['error'] = sprintf($this->language->get('error_seo_exists'), $item['keyword']);
					break;
				}

				$conflict = $this->model_design_seo_url->getSeoUrlByKeyword($item['keyword'], $item['store_id']);

				if ($conflict && (($conflict['key'] ?? '') !== $item['key'] || (string)($conflict['value'] ?? '') !== $item['value'])) {
					$json['error'] = sprintf($this->language->get('error_seo_exists'), $item['keyword']);
					break;
				}

				$used[$slot] = true;
				$pending[] = $item;
			}

			if (!$json) {
				$inserted = 0;

				foreach ($pending as $item) {
					$current = $this->russianSeoKeyword($item['key'], $item['value'], $item['store_id'], $language_id);

					if ($current !== '') {
						$written[] = [
							'key' => $item['token'],
							'current' => $current,
							'skipped' => true
						];
						continue;
					}

					$this->model_design_seo_url->addSeoUrl($item['key'], $item['value'], $item['keyword'], $item['store_id'], $language_id, $item['sort_order']);
					$inserted++;

					$written[] = [
						'key' => $item['token'],
						'current' => $item['keyword'],
						'skipped' => false
					];
				}

				$json['success'] = $inserted > 0
					? sprintf($this->language->get('text_seo_success'), (string)$inserted)
					: $this->language->get('text_seo_none');
				$json['rows'] = $written;
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function install(): void
	{
		if ($this->user->hasPermission('modify', 'extension/language')) {
			$this->load->model('localisation/language');

			$language_info = $this->model_localisation_language->getLanguageByCode('ru-ru');

			if (!$language_info) {
				$language_data = [
					'name' => 'Русский',
					'code' => 'ru-ru',
					'locale' => 'ru-ru',
					'extension' => 'ocn_language_russian',
					'status' => 1,
					'sort_order' => 1
				];

				$language_id = $this->model_localisation_language->addLanguage($language_data);
			} else {
				$language_id = (int)$language_info['language_id'];

				$this->model_localisation_language->editLanguage($language_id, $language_info + ['extension' => 'ocn_language_russian']);
			}

			$this->fillRussianMeta($language_id);
		}
	}

	public function uninstall(): void
	{
		if ($this->user->hasPermission('modify', 'extension/language')) {
			$this->load->model('localisation/language');

			$language_info = $this->model_localisation_language->getLanguageByCode('ru-ru');

			if ($language_info) {
				$this->model_localisation_language->deleteLanguage($language_info['language_id']);
			}
		}
	}

	/**
	 * @return array<string, array<string, string>>
	 */
	private function presets(): array
	{
		return [
			'bryansk' => [
				'label' => 'text_preset_bryansk',
				'country_iso' => 'RU',
				'zone_code' => 'RU-BRY',
				'timezone' => 'Europe/Moscow',
				'language' => 'ru-ru',
				'currency' => 'RUB'
			],
			'moscow' => [
				'label' => 'text_preset_moscow',
				'country_iso' => 'RU',
				'zone_code' => 'RU-MOW',
				'timezone' => 'Europe/Moscow',
				'language' => 'ru-ru',
				'currency' => 'RUB'
			],
			'russia' => [
				'label' => 'text_preset_russia',
				'country_iso' => 'RU',
				'zone_code' => '',
				'timezone' => 'Europe/Moscow',
				'language' => 'ru-ru',
				'currency' => 'RUB'
			]
		];
	}

	/**
	 * @return array<string, bool>
	 */
	private function requestedDefaults(): array
	{
		return [
			'country' => !empty($this->request->post['language_russian_default_country']),
			'zone' => (string)($this->request->post['language_russian_preset'] ?? '') !== 'russia' && (int)($this->request->post['language_russian_zone_id'] ?? 0) > 0,
			'timezone' => !empty($this->request->post['language_russian_default_timezone']),
			'language' => !empty($this->request->post['language_russian_default_language']),
			'language_admin' => !empty($this->request->post['language_russian_default_language_admin']),
			'currency' => !empty($this->request->post['language_russian_default_currency'])
		];
	}

	/**
	 * @param array<string, bool> $apply
	 *
	 * @return array{error: string, values: array<string, string>}
	 */
	private function resolvePreset(string $code, array $apply): array
	{
		$presets = $this->presets();

		if ($code === '' || !isset($presets[$code])) {
			return [
				'error' => $this->language->get('error_preset'),
				'values' => []
			];
		}

		$preset = $presets[$code];
		$errors = [];
		$values = [];

		$country_id = 0;

		if (!empty($apply['country']) || !empty($apply['zone'])) {
			$country_id = $this->findCountryId($preset['country_iso']);
		}

		if (!empty($apply['country'])) {
			if (!$country_id) {
				$errors[] = $this->language->get('error_country');
			} else {
				$values['config_country_id'] = (string)$country_id;
			}
		}

		if (!empty($apply['zone'])) {
			if (!$country_id) {
				if (!in_array($this->language->get('error_country'), $errors, true)) {
					$errors[] = $this->language->get('error_country');
				}
			} else {
				$zone_id = $this->resolveZoneId($country_id);

				if (!$zone_id) {
					$errors[] = $this->language->get('error_zone_select');
				} else {
					$values['config_zone_id'] = (string)$zone_id;
				}
			}
		}

		if (!empty($apply['timezone'])) {
			$values['config_timezone'] = $preset['timezone'];
		}

		if (!empty($apply['language']) || !empty($apply['language_admin'])) {
			$this->load->model('localisation/language');

			$language_info = $this->model_localisation_language->getLanguageByCode($preset['language']);

			if (!$language_info) {
				$errors[] = $this->language->get('error_language');
			} else {
				if (!empty($apply['language'])) {
					$values['config_language_catalog'] = $language_info['code'];
				}

				if (!empty($apply['language_admin'])) {
					$values['config_language_admin'] = $language_info['code'];
				}
			}
		}

		if (!empty($apply['currency'])) {
			$this->load->model('localisation/currency');

			$currency_info = $this->model_localisation_currency->getCurrencyByCode($preset['currency']);

			if (!$currency_info) {
				$errors[] = $this->language->get('error_currency');
			} else {
				$values['config_currency'] = $currency_info['code'];
			}
		}

		if ($errors) {
			$values = [];
		}

		return [
			'error' => implode('<br>', $errors),
			'values' => $values
		];
	}

	private function findCountryId(string $iso_code_2): int
	{
		$query = $this->db->query("SELECT `country_id` FROM `" . DB_PREFIX . "country` WHERE `iso_code_2` = '" . $this->db->escape($iso_code_2) . "' LIMIT 1");

		return $query->num_rows ? (int)$query->row['country_id'] : 0;
	}

	private function resolveZoneId(int $country_id): int
	{
		$zone_id = (int)($this->request->post['language_russian_zone_id'] ?? 0);

		return $this->zoneBelongsToCountry($zone_id, $country_id) ? $zone_id : 0;
	}

	private function zoneBelongsToCountry(int $zone_id, int $country_id): bool
	{
		if ($zone_id < 1 || $country_id < 1) {
			return false;
		}

		$query = $this->db->query("SELECT `zone_id` FROM `" . DB_PREFIX . "zone` WHERE `zone_id` = '" . (int)$zone_id . "' AND `country_id` = '" . (int)$country_id . "' AND `status` = '1' LIMIT 1");

		return (bool)$query->num_rows;
	}

	private function storedZoneId(): string
	{
		if ((string)($this->request->post['language_russian_preset'] ?? '') === 'russia') {
			return '';
		}

		$zone_id = (int)($this->request->post['language_russian_zone_id'] ?? 0);

		if ($zone_id < 1) {
			return '';
		}

		$country_id = $this->findCountryId('RU');

		if ($this->zoneBelongsToCountry($zone_id, $country_id)) {
			return (string)$zone_id;
		}

		$previous = (int)$this->config->get('language_russian_zone_id');

		return $this->zoneBelongsToCountry($previous, $country_id) ? (string)$previous : '';
	}

	/**
	 * @return array<int, array{zone_id: int, code: string, name: string}>
	 */
	private function countryZones(int $country_id): array
	{
		$language_id = (int)$this->config->get('config_language_id');

		$query = $this->db->query("SELECT `z`.`zone_id`, `z`.`code`, COALESCE(NULLIF(`zd`.`name`, ''), NULLIF(`zd1`.`name`, ''), `z`.`code`) AS `name` FROM `" . DB_PREFIX . "zone` `z` LEFT JOIN `" . DB_PREFIX . "zone_description` `zd` ON (`z`.`zone_id` = `zd`.`zone_id` AND `zd`.`language_id` = '" . $language_id . "') LEFT JOIN `" . DB_PREFIX . "zone_description` `zd1` ON (`z`.`zone_id` = `zd1`.`zone_id` AND `zd1`.`language_id` = '1') WHERE `z`.`country_id` = '" . (int)$country_id . "' AND `z`.`status` = '1'");

		$labels = $this->russianZoneLabels();
		$zones = [];

		foreach ($query->rows as $row) {
			$code = (string)$row['code'];

			$zones[] = [
				'zone_id' => (int)$row['zone_id'],
				'code' => $code,
				'name' => $labels[$code] ?? (string)$row['name']
			];
		}

		usort($zones, static function (array $a, array $b): int {
			return strcmp($a['name'], $b['name']);
		});

		return $zones;
	}

	/**
	 * @return array<string, string>
	 */
	private function russianZoneLabels(): array
	{
		return $this->localisationMap()['region'];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function localisationMap(): array
	{
		static $map = null;

		if (is_array($map)) {
			return $map;
		}

		$file = DIR_EXTENSION . 'ocn_language_russian/system/localisation_ru.php';
		$loaded = is_file($file) ? require $file : [];

		if (!is_array($loaded)) {
			$loaded = [];
		}

		foreach (['country', 'region', 'length', 'weight', 'stock_status', 'order_status', 'return_status', 'return_action', 'return_reason', 'subscription_status', 'customer_group', 'currency'] as $key) {
			if (!isset($loaded[$key]) || !is_array($loaded[$key])) {
				$loaded[$key] = [];
			}
		}

		$map = $loaded;

		return $map;
	}

	private function russianLanguageId(): int
	{
		$this->load->model('localisation/language');

		$language_info = $this->model_localisation_language->getLanguageByCode('ru-ru');

		return $language_info ? (int)$language_info['language_id'] : 0;
	}

	/**
	 * @return array<string, array{label: string, key: string, value: string, keyword: string}>
	 */
	private function seoPages(): array
	{
		return [
			'register' => [
				'label' => 'text_seo_register',
				'key' => 'route',
				'value' => 'account/register',
				'keyword' => 'register'
			],
			'login' => [
				'label' => 'text_seo_login',
				'key' => 'route',
				'value' => 'account/login',
				'keyword' => 'login'
			],
			'logout' => [
				'label' => 'text_seo_logout',
				'key' => 'route',
				'value' => 'account/logout',
				'keyword' => 'logout'
			],
			'forgotten' => [
				'label' => 'text_seo_forgotten',
				'key' => 'route',
				'value' => 'account/forgotten',
				'keyword' => 'forgotten'
			],
			'account' => [
				'label' => 'text_seo_account',
				'key' => 'route',
				'value' => 'account/account',
				'keyword' => 'account'
			],
			'edit' => [
				'label' => 'text_seo_edit',
				'key' => 'route',
				'value' => 'account/edit',
				'keyword' => 'edit'
			],
			'password' => [
				'label' => 'text_seo_password',
				'key' => 'route',
				'value' => 'account/password',
				'keyword' => 'password'
			],
			'address' => [
				'label' => 'text_seo_address',
				'key' => 'route',
				'value' => 'account/address',
				'keyword' => 'address'
			],
			'wishlist' => [
				'label' => 'text_seo_wishlist',
				'key' => 'route',
				'value' => 'account/wishlist',
				'keyword' => 'wishlist'
			],
			'order' => [
				'label' => 'text_seo_order',
				'key' => 'route',
				'value' => 'account/order',
				'keyword' => 'order'
			],
			'download' => [
				'label' => 'text_seo_download',
				'key' => 'route',
				'value' => 'account/download',
				'keyword' => 'download'
			],
			'newsletter' => [
				'label' => 'text_seo_newsletter',
				'key' => 'route',
				'value' => 'account/newsletter',
				'keyword' => 'newsletter'
			],
			'returns' => [
				'label' => 'text_seo_returns',
				'key' => 'route',
				'value' => 'account/returns',
				'keyword' => 'returns'
			],
			'transaction' => [
				'label' => 'text_seo_transaction',
				'key' => 'route',
				'value' => 'account/transaction',
				'keyword' => 'transaction'
			],
			'reward' => [
				'label' => 'text_seo_reward',
				'key' => 'route',
				'value' => 'account/reward',
				'keyword' => 'reward'
			],
			'subscription' => [
				'label' => 'text_seo_subscription',
				'key' => 'route',
				'value' => 'account/subscription',
				'keyword' => 'subscription'
			],
			'cart' => [
				'label' => 'text_seo_cart',
				'key' => 'route',
				'value' => 'checkout/cart',
				'keyword' => 'cart'
			],
			'checkout' => [
				'label' => 'text_seo_checkout',
				'key' => 'route',
				'value' => 'checkout/checkout',
				'keyword' => 'checkout'
			],
			'search' => [
				'label' => 'text_seo_search',
				'key' => 'route',
				'value' => 'product/search',
				'keyword' => 'search'
			],
			'compare' => [
				'label' => 'text_seo_compare',
				'key' => 'route',
				'value' => 'product/compare',
				'keyword' => 'compare'
			],
			'manufacturer' => [
				'label' => 'text_seo_manufacturer',
				'key' => 'route',
				'value' => 'product/manufacturer',
				'keyword' => 'brands'
			],
			'manufacturer_info' => [
				'label' => 'text_seo_manufacturer_info',
				'key' => 'route',
				'value' => 'product/manufacturer.info',
				'keyword' => 'brand'
			],
			'special' => [
				'label' => 'text_seo_special',
				'key' => 'route',
				'value' => 'product/special',
				'keyword' => 'special'
			],
			'contact' => [
				'label' => 'text_seo_contact',
				'key' => 'route',
				'value' => 'information/contact',
				'keyword' => 'contact'
			],
			'sitemap' => [
				'label' => 'text_seo_sitemap',
				'key' => 'route',
				'value' => 'information/sitemap',
				'keyword' => 'sitemap'
			],
			'blog' => [
				'label' => 'text_seo_blog',
				'key' => 'route',
				'value' => 'cms/blog',
				'keyword' => 'blog'
			],
			'blog_info' => [
				'label' => 'text_seo_blog_info',
				'key' => 'route',
				'value' => 'cms/blog.info',
				'keyword' => 'article'
			]
		];
	}

	/**
	 * @return array{rows: array<int, array<string, mixed>>, error: string, multi_store: bool}
	 */
	private function seoView(): array
	{
		$language_id = $this->russianLanguageId();

		if (!$language_id) {
			return [
				'rows' => [],
				'error' => $this->language->get('error_seo_language'),
				'multi_store' => false
			];
		}

		$rows = [];
		$stores = [];

		foreach ($this->seoPages() as $code => $page) {
			foreach ($this->seoTargets($page) as $target) {
				$store_id = $target['store_id'];
				$stores[$store_id] = true;

				$rows[] = [
					'id' => $code . ':' . $store_id,
					'label' => $this->language->get($page['label']),
					'key' => $page['key'],
					'value' => $page['value'],
					'store_id' => $store_id,
					'store' => $this->seoStoreName($store_id),
					'current' => $this->russianSeoKeyword($page['key'], $page['value'], $store_id, $language_id),
					'keyword' => $target['keyword']
				];
			}
		}

		return [
			'rows' => $rows,
			'error' => '',
			'multi_store' => count($stores) > 1
		];
	}

	/**
	 * @param array{label: string, key: string, value: string, keyword: string} $page
	 *
	 * @return array<int, array{store_id: int, keyword: string, sort_order: int}>
	 */
	private function seoTargets(array $page): array
	{
		$this->load->model('localisation/language');

		$language_info = $this->model_localisation_language->getLanguageByCode('en-gb');
		$targets = [];
		$install = $this->englishInstallKeywords();

		if ($language_info) {
			$query = $this->db->query("SELECT `store_id`, `keyword`, `sort_order` FROM `" . DB_PREFIX . "seo_url` WHERE `language_id` = '" . (int)$language_info['language_id'] . "' AND `key` = '" . $this->db->escape($page['key']) . "' AND `value` = '" . $this->db->escape($page['value']) . "' ORDER BY `store_id` ASC, `seo_url_id` ASC");

			foreach ($query->rows as $row) {
				$store_id = (int)$row['store_id'];

				if (isset($targets[$store_id])) {
					continue;
				}

				$keyword = trim((string)$row['keyword']);

				if ($keyword === '') {
					$keyword = $install[$page['value']][$store_id] ?? '';
				}

				$targets[$store_id] = [
					'store_id' => $store_id,
					'keyword' => $keyword !== '' ? $keyword : $page['keyword'],
					'sort_order' => (int)$row['sort_order']
				];
			}
		}

		if (!isset($targets[0])) {
			$keyword = $install[$page['value']][0] ?? '';

			$targets[0] = [
				'store_id' => 0,
				'keyword' => $keyword !== '' ? $keyword : $page['keyword'],
				'sort_order' => 0
			];
		}

		ksort($targets);

		return $targets;
	}

	/**
	 * @return array<string, array<int, string>>
	 */
	private function englishInstallKeywords(): array
	{
		static $map = null;

		if ($map !== null) {
			return $map;
		}

		$map = [];
		$path = DIR_OPENCART . 'install/opencart-en-gb.sql';

		if (!is_file($path)) {
			return $map;
		}

		$sql = file_get_contents($path);

		if (!is_string($sql) || $sql === '') {
			return $map;
		}

		$pattern = '/\\(\\s*(\\d+)\\s*,\\s*\\d+\\s*,\\s*' . "'route'" . '\\s*,\\s*' . "'([^']*)'" . '\\s*,\\s*' . "'([^']*)'/";

		if (preg_match_all($pattern, $sql, $matches, PREG_SET_ORDER)) {
			foreach ($matches as $match) {
				$store_id = (int)$match[1];
				$value = str_replace("\\'", "'", $match[2]);
				$keyword = str_replace("\\'", "'", $match[3]);

				if ($keyword === '' || isset($map[$value][$store_id])) {
					continue;
				}

				$map[$value][$store_id] = $keyword;
			}
		}

		return $map;
	}

	/**
	 * @param array<string, array{label: string, key: string, value: string, keyword: string}> $pages
	 * @param array<mixed> $keywords
	 *
	 * @return array{error: string, token: string, key: string, value: string, store_id: int, keyword: string, sort_order: int}|null
	 */
	private function seoPlanItem(string $token, array $pages, array $keywords): ?array
	{
		$parts = explode(':', $token, 2);

		if (count($parts) !== 2 || !isset($pages[$parts[0]]) || !preg_match('/^[0-9]+$/', $parts[1])) {
			return null;
		}

		$page = $pages[$parts[0]];
		$store_id = (int)$parts[1];
		$targets = $this->seoTargets($page);

		if (!isset($targets[$store_id])) {
			return null;
		}

		$keyword = $this->clip((string)($keywords[$token] ?? ''), 64);

		if ($keyword === '') {
			return [
				'error' => sprintf($this->language->get('error_seo_keyword_empty'), $page['value']),
				'token' => $token,
				'key' => $page['key'],
				'value' => $page['value'],
				'store_id' => $store_id,
				'keyword' => '',
				'sort_order' => 0
			];
		}

		if (!$this->seoKeywordAllowed($keyword)) {
			return [
				'error' => sprintf($this->language->get('error_seo_keyword'), $keyword),
				'token' => $token,
				'key' => $page['key'],
				'value' => $page['value'],
				'store_id' => $store_id,
				'keyword' => $keyword,
				'sort_order' => 0
			];
		}

		return [
			'error' => '',
			'token' => $token,
			'key' => $page['key'],
			'value' => $page['value'],
			'store_id' => $store_id,
			'keyword' => $keyword,
			'sort_order' => $targets[$store_id]['sort_order']
		];
	}

	private function seoKeywordAllowed(string $keyword): bool
	{
		if (!oc_validate_length($keyword, 1, 64) || !oc_validate_path($keyword)) {
			return false;
		}

		foreach (explode('/', $keyword) as $part) {
			if (!oc_validate_length($part, 1, 64) || !oc_validate_path($part)) {
				return false;
			}
		}

		return true;
	}

	private function russianSeoKeyword(string $key, string $value, int $store_id, int $language_id): string
	{
		$query = $this->db->query("SELECT `keyword` FROM `" . DB_PREFIX . "seo_url` WHERE `key` = '" . $this->db->escape($key) . "' AND `value` = '" . $this->db->escape($value) . "' AND `store_id` = '" . (int)$store_id . "' AND `language_id` = '" . (int)$language_id . "' ORDER BY `seo_url_id` ASC LIMIT 1");

		return $query->num_rows ? (string)$query->row['keyword'] : '';
	}

	private function seoStoreName(int $store_id): string
	{
		if ($store_id === 0) {
			return $this->language->get('text_seo_store_default');
		}

		$query = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "store` WHERE `store_id` = '" . (int)$store_id . "' LIMIT 1");

		return $query->num_rows ? (string)$query->row['name'] : (string)$store_id;
	}

	/**
	 * @return array<string, array{zone_id: int, name: string}>
	 */
	private function russianZoneRecords(int $country_id, int $language_id): array
	{
		$query = $this->db->query("SELECT `z`.`zone_id`, `z`.`code`, `zd`.`name` FROM `" . DB_PREFIX . "zone` `z` LEFT JOIN `" . DB_PREFIX . "zone_description` `zd` ON (`z`.`zone_id` = `zd`.`zone_id` AND `zd`.`language_id` = '" . (int)$language_id . "') WHERE `z`.`country_id` = '" . (int)$country_id . "'");

		$zones = [];

		foreach ($query->rows as $row) {
			$zones[(string)$row['code']] = [
				'zone_id' => (int)$row['zone_id'],
				'name' => (string)($row['name'] ?? '')
			];
		}

		return $zones;
	}

	/**
	 * @return array{groups: array<int, array<string, mixed>>, all: bool, error: string}
	 */
	private function translationView(): array
	{
		$language_id = $this->russianLanguageId();

		if (!$language_id) {
			return [
				'groups' => [],
				'all' => false,
				'error' => $this->language->get('error_translation_language')
			];
		}

		$map = $this->localisationMap();
		$groups = [];

		$groups[] = $this->translationGroup('country', $this->language->get('text_group_country'), '', [
			$this->translationSection('country', '', $this->countryTranslationRows($map, $language_id), false)
		]);
		$groups[] = $this->translationGroup('region', $this->language->get('text_group_region'), '', [
			$this->translationSection('region', '', $this->regionTranslationRows($map, $language_id), false)
		]);
		$groups[] = $this->translationGroup('length', $this->language->get('text_group_length'), '', [
			$this->translationSection('length', '', $this->measureTranslationRows('length', $map['length'], $language_id), true)
		]);
		$groups[] = $this->translationGroup('weight', $this->language->get('text_group_weight'), '', [
			$this->translationSection('weight', '', $this->measureTranslationRows('weight', $map['weight'], $language_id), true)
		]);
		$groups[] = $this->translationGroup('stock', $this->language->get('text_group_stock'), '', [
			$this->translationSection('stock', '', $this->statusTranslationRows('stock_status', 'stock_status_id', 'stock', $map['stock_status'], $language_id), false)
		]);
		$groups[] = $this->translationGroup('order', $this->language->get('text_group_order'), '', [
			$this->translationSection('order', '', $this->statusTranslationRows('order_status', 'order_status_id', 'order', $map['order_status'], $language_id), false)
		]);
		$groups[] = $this->translationGroup('return', $this->language->get('text_group_return'), '', [
			$this->translationSection('return_status', $this->language->get('text_group_return_status'), $this->statusTranslationRows('return_status', 'return_status_id', 'return_status', $map['return_status'], $language_id), false),
			$this->translationSection('return_action', $this->language->get('text_group_return_action'), $this->statusTranslationRows('return_action', 'return_action_id', 'return_action', $map['return_action'], $language_id), false),
			$this->translationSection('return_reason', $this->language->get('text_group_return_reason'), $this->statusTranslationRows('return_reason', 'return_reason_id', 'return_reason', $map['return_reason'], $language_id), false)
		]);
		$groups[] = $this->translationGroup('subscription', $this->language->get('text_group_subscription'), '', [
			$this->translationSection('subscription', '', $this->statusTranslationRows('subscription_status', 'subscription_status_id', 'subscription', $map['subscription_status'], $language_id), false)
		]);
		$groups[] = $this->translationGroup('customer_group', $this->language->get('text_group_customer'), '', [
			$this->translationSection('customer_group', '', $this->customerGroupTranslationRows($map['customer_group'], $language_id), true)
		]);
		$groups[] = $this->translationGroup('currency', $this->language->get('text_group_currency'), $this->language->get('text_translation_currency'), [
			$this->translationSection('currency', '', $this->currencyTranslationRows($map['currency']), false)
		]);

		$groups = array_values(array_filter($groups));
		$all = $groups !== [];

		foreach ($groups as $group) {
			foreach ($group['sections'] as $section) {
				if (!$section['all']) {
					$all = false;
					break 2;
				}
			}
		}

		return [
			'groups' => $groups,
			'all' => $all,
			'error' => ''
		];
	}

	/**
	 * @param array<int, array<string, mixed>> $sections
	 *
	 * @return array<string, mixed>
	 */
	private function translationGroup(string $code, string $title, string $note, array $sections): array
	{
		$sections = array_values(array_filter($sections));

		if (!$sections) {
			return [];
		}

		return [
			'code' => $code,
			'title' => $title,
			'note' => $note,
			'sections' => $sections
		];
	}

	/**
	 * @param array<int, array<string, mixed>> $rows
	 *
	 * @return array<string, mixed>
	 */
	private function translationSection(string $code, string $title, array $rows, bool $dual): array
	{
		if (!$rows) {
			return [];
		}

		foreach ($rows as $index => $row) {
			$rows[$index]['apply'] = false;
		}

		return [
			'code' => $code,
			'title' => $title,
			'dual' => $dual,
			'rows' => $rows,
			'all' => false
		];
	}

	/**
	 * @param array<string, mixed> $map
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function countryTranslationRows(array $map, int $language_id): array
	{
		$name = trim((string)($map['country']['RU'] ?? ''));
		$country_id = $this->findCountryId('RU');

		if ($name === '' || !$country_id) {
			return [];
		}

		$query = $this->db->query("SELECT `name` FROM `" . DB_PREFIX . "country_description` WHERE `country_id` = '" . (int)$country_id . "' AND `language_id` = '" . (int)$language_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return [];
		}

		$current = (string)$query->row['name'];

		return [[
			'key' => 'country:RU',
			'label' => 'RU',
			'current' => $current,
			'current_extra' => '',
			'name' => $name,
			'extra' => '',
			'apply' => $current !== $name
		]];
	}

	/**
	 * @param array<string, mixed> $map
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function regionTranslationRows(array $map, int $language_id): array
	{
		$country_id = $this->findCountryId('RU');

		if (!$country_id) {
			return [];
		}

		$zones = $this->russianZoneRecords($country_id, $language_id);
		$rows = [];

		foreach ($map['region'] as $code => $name) {
			$code = (string)$code;
			$name = trim((string)$name);

			if ($name === '' || !isset($zones[$code])) {
				continue;
			}

			$current = $zones[$code]['name'];

			$rows[] = [
				'key' => 'region:' . $code,
				'label' => $code,
				'current' => $current,
				'current_extra' => '',
				'name' => $name,
				'extra' => '',
				'apply' => $current !== $name
			];
		}

		usort($rows, static function (array $a, array $b): int {
			return strcmp($a['name'], $b['name']);
		});

		return $rows;
	}

	/**
	 * @param array<string, mixed> $definitions
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function measureTranslationRows(string $type, array $definitions, int $language_id): array
	{
		$table = $type === 'weight' ? 'weight_class' : 'length_class';
		$id_column = $table . '_id';
		$query = $this->db->query("SELECT `c`.`" . $id_column . "` AS `id`, `c`.`value`, `d`.`title`, `d`.`unit` FROM `" . DB_PREFIX . $table . "` `c` LEFT JOIN `" . DB_PREFIX . $table . "_description` `d` ON (`c`.`" . $id_column . "` = `d`.`" . $id_column . "` AND `d`.`language_id` = '" . (int)$language_id . "')");
		$rows = [];

		foreach ($definitions as $code => $definition) {
			if (!is_array($definition)) {
				continue;
			}

			$code = (string)$code;
			$title = trim((string)($definition['title'] ?? ''));
			$unit = trim((string)($definition['unit'] ?? ''));
			$match = $this->matchMeasure($query->rows, $code, $unit, (string)($definition['value'] ?? ''));

			if (!$match || ($title === '' && $unit === '')) {
				continue;
			}

			$current_title = (string)$match['title'];
			$current_unit = (string)$match['unit'];

			$rows[] = [
				'key' => $type . ':' . $code,
				'label' => $code,
				'current' => $current_title,
				'current_extra' => $current_unit,
				'name' => $title,
				'extra' => $unit,
				'apply' => $current_title !== $title || $current_unit !== $unit
			];
		}

		return $rows;
	}

	/**
	 * @param array<int, array<string, mixed>> $rows
	 *
	 * @return array<string, mixed>|null
	 */
	private function matchMeasure(array $rows, string $unit, string $new_unit, string $value): ?array
	{
		foreach ([$unit, $new_unit] as $candidate) {
			if ($candidate === '') {
				continue;
			}

			foreach ($rows as $row) {
				if ((string)$row['unit'] === $candidate && $row['title'] !== null) {
					return $row;
				}
			}
		}

		if ($value === '') {
			return null;
		}

		foreach ($rows as $row) {
			$current_unit = (string)$row['unit'];

			if ($row['title'] === null) {
				continue;
			}

			if (abs((float)$row['value'] - (float)$value) < 0.0000001 && ($current_unit === $unit || $current_unit === $new_unit)) {
				return $row;
			}
		}

		return null;
	}

	/**
	 * @param array<int|string, mixed> $names
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function statusTranslationRows(string $table, string $id_column, string $type, array $names, int $language_id): array
	{
		$ids = [];

		foreach (array_keys($names) as $id) {
			$id = (int)$id;

			if ($id > 0) {
				$ids[] = $id;
			}
		}

		if (!$ids) {
			return [];
		}

		$query = $this->db->query("SELECT `" . $id_column . "` AS `id`, `name` FROM `" . DB_PREFIX . $table . "` WHERE `language_id` = '" . (int)$language_id . "' AND `" . $id_column . "` IN (" . implode(',', $ids) . ")");
		$current = [];

		foreach ($query->rows as $row) {
			$current[(int)$row['id']] = (string)$row['name'];
		}

		$rows = [];

		foreach ($names as $id => $name) {
			$id = (int)$id;
			$name = trim((string)$name);

			if ($id < 1 || $name === '' || !isset($current[$id])) {
				continue;
			}

			$rows[] = [
				'key' => $type . ':' . $id,
				'label' => (string)$id,
				'current' => $current[$id],
				'current_extra' => '',
				'name' => $name,
				'extra' => '',
				'apply' => $current[$id] !== $name
			];
		}

		return $rows;
	}

	/**
	 * @param array<int|string, mixed> $definitions
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function customerGroupTranslationRows(array $definitions, int $language_id): array
	{
		$ids = [];

		foreach (array_keys($definitions) as $id) {
			$id = (int)$id;

			if ($id > 0) {
				$ids[] = $id;
			}
		}

		if (!$ids) {
			return [];
		}

		$query = $this->db->query("SELECT `customer_group_id` AS `id`, `name`, `description` FROM `" . DB_PREFIX . "customer_group_description` WHERE `language_id` = '" . (int)$language_id . "' AND `customer_group_id` IN (" . implode(',', $ids) . ")");
		$current = [];

		foreach ($query->rows as $row) {
			$current[(int)$row['id']] = $row;
		}

		$rows = [];

		foreach ($definitions as $id => $definition) {
			$id = (int)$id;

			if ($id < 1 || !is_array($definition) || !isset($current[$id])) {
				continue;
			}

			$name = trim((string)($definition['name'] ?? ''));
			$description = trim((string)($definition['description'] ?? ''));
			$current_name = (string)$current[$id]['name'];
			$current_description = (string)$current[$id]['description'];

			if ($name === '' && $description === '') {
				continue;
			}

			$rows[] = [
				'key' => 'customer_group:' . $id,
				'label' => (string)$id,
				'current' => $current_name,
				'current_extra' => $current_description,
				'name' => $name,
				'extra' => $description,
				'apply' => $current_name !== $name || $current_description !== $description
			];
		}

		return $rows;
	}

	/**
	 * @param array<string, mixed> $definitions
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function currencyTranslationRows(array $definitions): array
	{
		$title = trim((string)($definitions['RUB'] ?? ''));

		if ($title === '') {
			return [];
		}

		$query = $this->db->query("SELECT `title` FROM `" . DB_PREFIX . "currency` WHERE `code` = 'RUB' LIMIT 1");

		if (!$query->num_rows) {
			return [];
		}

		return [[
			'key' => 'currency:RUB',
			'label' => 'RUB',
			'current' => (string)$query->row['title'],
			'current_extra' => '',
			'name' => $title,
			'extra' => '',
			'apply' => false
		]];
	}

	/**
	 * @return array{key: string, current: string, current_extra: string}|null
	 */
	private function writeTranslation(string $type, string $code, string $name, string $extra, int $language_id): ?array
	{
		$map = $this->localisationMap();

		if ($type === 'country' && $code === 'RU') {
			$name = $this->clip($name, 128);
			$country_id = $this->findCountryId('RU');

			if ($name === '' || !$country_id || !$this->updateNamedRow('country_description', 'country_id', $country_id, $language_id, $name)) {
				return null;
			}

			return ['key' => 'country:RU', 'current' => $name, 'current_extra' => ''];
		}

		if ($type === 'region' && isset($map['region'][$code])) {
			$name = $this->clip($name, 128);
			$country_id = $this->findCountryId('RU');
			$zones = $country_id ? $this->russianZoneRecords($country_id, $language_id) : [];

			if ($name === '' || !isset($zones[$code]) || !$this->updateNamedRow('zone_description', 'zone_id', (int)$zones[$code]['zone_id'], $language_id, $name)) {
				return null;
			}

			return ['key' => 'region:' . $code, 'current' => $name, 'current_extra' => ''];
		}

		if (($type === 'length' || $type === 'weight') && isset($map[$type][$code]) && is_array($map[$type][$code])) {
			return $this->writeMeasure($type, $code, $name, $extra, $language_id);
		}

		$status = [
			'stock' => ['stock_status', 'stock_status_id', 'stock_status'],
			'order' => ['order_status', 'order_status_id', 'order_status'],
			'return_status' => ['return_status', 'return_status_id', 'return_status'],
			'return_action' => ['return_action', 'return_action_id', 'return_action'],
			'return_reason' => ['return_reason', 'return_reason_id', 'return_reason'],
			'subscription' => ['subscription_status', 'subscription_status_id', 'subscription_status']
		];

		if (isset($status[$type])) {
			$id = (int)$code;
			$name = $this->clip($name, 32);
			$source = $status[$type][2];

			if ($id < 1 || $name === '' || !isset($map[$source][$id]) || !$this->updateNamedRow($status[$type][0], $status[$type][1], $id, $language_id, $name)) {
				return null;
			}

			return ['key' => $type . ':' . $id, 'current' => $name, 'current_extra' => ''];
		}

		if ($type === 'customer_group') {
			return $this->writeCustomerGroup((int)$code, $name, $extra, $language_id);
		}

		if ($type === 'currency' && $code === 'RUB') {
			$name = $this->clip($name, 32);

			if ($name === '' || !isset($map['currency']['RUB'])) {
				return null;
			}

			$query = $this->db->query("SELECT `currency_id` FROM `" . DB_PREFIX . "currency` WHERE `code` = 'RUB' LIMIT 1");

			if (!$query->num_rows) {
				return null;
			}

			$this->db->query("UPDATE `" . DB_PREFIX . "currency` SET `title` = '" . $this->db->escape($name) . "' WHERE `code` = 'RUB'");

			return ['key' => 'currency:RUB', 'current' => $name, 'current_extra' => ''];
		}

		return null;
	}

	/**
	 * @return array{key: string, current: string, current_extra: string}|null
	 */
	private function writeMeasure(string $type, string $code, string $name, string $extra, int $language_id): ?array
	{
		$map = $this->localisationMap();
		$definition = $map[$type][$code];
		$table = $type === 'weight' ? 'weight_class' : 'length_class';
		$id_column = $table . '_id';
		$name = $this->clip($name, 32);
		$extra = $this->clip($extra, 4);

		if ($name === '' && $extra === '') {
			return null;
		}

		$query = $this->db->query("SELECT `c`.`" . $id_column . "` AS `id`, `c`.`value`, `d`.`title`, `d`.`unit` FROM `" . DB_PREFIX . $table . "` `c` LEFT JOIN `" . DB_PREFIX . $table . "_description` `d` ON (`c`.`" . $id_column . "` = `d`.`" . $id_column . "` AND `d`.`language_id` = '" . (int)$language_id . "')");
		$match = $this->matchMeasure($query->rows, $code, (string)($definition['unit'] ?? ''), (string)($definition['value'] ?? ''));

		if (!$match) {
			return null;
		}

		$fields = [];

		if ($name !== '') {
			$fields[] = "`title` = '" . $this->db->escape($name) . "'";
		}

		if ($extra !== '') {
			$fields[] = "`unit` = '" . $this->db->escape($extra) . "'";
		}

		$this->db->query("UPDATE `" . DB_PREFIX . $table . "_description` SET " . implode(', ', $fields) . " WHERE `" . $id_column . "` = '" . (int)$match['id'] . "' AND `language_id` = '" . (int)$language_id . "'");

		$current_title = $name !== '' ? $name : (string)$match['title'];
		$current_unit = $extra !== '' ? $extra : (string)$match['unit'];

		return [
			'key' => $type . ':' . $code,
			'current' => $current_title,
			'current_extra' => $current_unit
		];
	}

	/**
	 * @return array{key: string, current: string, current_extra: string}|null
	 */
	private function writeCustomerGroup(int $id, string $name, string $extra, int $language_id): ?array
	{
		$map = $this->localisationMap();
		$name = $this->clip($name, 32);
		$extra = $this->clip($extra, 65535);

		if ($id < 1 || ($name === '' && $extra === '') || !isset($map['customer_group'][$id])) {
			return null;
		}

		$query = $this->db->query("SELECT `name`, `description` FROM `" . DB_PREFIX . "customer_group_description` WHERE `customer_group_id` = '" . (int)$id . "' AND `language_id` = '" . (int)$language_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return null;
		}

		$fields = [];

		if ($name !== '') {
			$fields[] = "`name` = '" . $this->db->escape($name) . "'";
		}

		if ($extra !== '') {
			$fields[] = "`description` = '" . $this->db->escape($extra) . "'";
		}

		$this->db->query("UPDATE `" . DB_PREFIX . "customer_group_description` SET " . implode(', ', $fields) . " WHERE `customer_group_id` = '" . (int)$id . "' AND `language_id` = '" . (int)$language_id . "'");

		return [
			'key' => 'customer_group:' . $id,
			'current' => $name !== '' ? $name : (string)$query->row['name'],
			'current_extra' => $extra !== '' ? $extra : (string)$query->row['description']
		];
	}

	private function updateNamedRow(string $table, string $id_column, int $id, int $language_id, string $name): bool
	{
		$allowed = [
			'country_description' => 'country_id',
			'zone_description' => 'zone_id',
			'stock_status' => 'stock_status_id',
			'order_status' => 'order_status_id',
			'return_status' => 'return_status_id',
			'return_action' => 'return_action_id',
			'return_reason' => 'return_reason_id',
			'subscription_status' => 'subscription_status_id'
		];

		if (!isset($allowed[$table]) || $allowed[$table] !== $id_column || $id < 1 || $name === '') {
			return false;
		}

		$query = $this->db->query("SELECT `" . $id_column . "` FROM `" . DB_PREFIX . $table . "` WHERE `" . $id_column . "` = '" . (int)$id . "' AND `language_id` = '" . (int)$language_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return false;
		}

		$this->db->query("UPDATE `" . DB_PREFIX . $table . "` SET `name` = '" . $this->db->escape($name) . "' WHERE `" . $id_column . "` = '" . (int)$id . "' AND `language_id` = '" . (int)$language_id . "'");

		return true;
	}

	private function clip(string $value, int $limit): string
	{
		$value = trim($value);

		if ($value === '') {
			return '';
		}

		return mb_substr($value, 0, $limit);
	}

	private function translationCacheKey(string $type): string
	{
		$caches = [
			'country' => 'country',
			'region' => 'zone',
			'length' => 'length_class',
			'weight' => 'weight_class',
			'stock' => 'stock_status',
			'order' => 'order_status',
			'return_status' => 'return_status',
			'return_action' => 'return_action',
			'return_reason' => 'return_reason',
			'subscription' => 'subscription_status',
			'customer_group' => 'customer_group',
			'currency' => 'currency'
		];

		return $caches[$type] ?? '';
	}

	/**
	 * @param array<string, string> $preset
	 *
	 * @return array<string, bool>
	 */
	private function localeMatches(array $preset, int $country_id): array
	{
		$catalog = trim((string)$this->config->get('config_language_catalog'));

		if ($catalog === '') {
			$catalog = trim((string)$this->config->get('config_language'));
		}

		return [
			'country' => $country_id > 0 && (string)$this->config->get('config_country_id') === (string)$country_id,
			'timezone' => (string)$this->config->get('config_timezone') === $preset['timezone'],
			'language' => $catalog === $preset['language'],
			'language_admin' => (string)$this->config->get('config_language_admin') === $preset['language'],
			'currency' => (string)$this->config->get('config_currency') === $preset['currency']
		];
	}

	/**
	 * @param array<int, array{zone_id: int, code: string, name: string}> $zones
	 */
	private function zoneByCode(array $zones, string $code): array
	{
		foreach ($zones as $zone) {
			if ($zone['code'] === $code) {
				return $zone;
			}
		}

		return [];
	}

	/**
	 * @return array{active: array<string, bool>, selected: string, zone_id: int, zones: array<int, array{zone_id: int, code: string, name: string}>, preset_zone_ids: array<string, int>}
	 */
	private function presetFormState(): array
	{
		$presets = $this->presets();
		$country_id = $this->findCountryId('RU');
		$zones = $country_id ? $this->countryZones($country_id) : [];
		$bryansk = $this->zoneByCode($zones, 'RU-BRY');
		$moscow = $this->zoneByCode($zones, 'RU-MOW');
		$config_zone_id = (int)$this->config->get('config_zone_id');
		$saved_zone_id = (int)$this->config->get('language_russian_zone_id');
		$saved_preset = (string)$this->config->get('language_russian_preset');

		if (!isset($presets[$saved_preset])) {
			$saved_preset = '';
		}

		$selected = $saved_preset;
		$shared = $this->localeMatches($presets['bryansk'], $country_id);
		$zone_ids = [];

		foreach ($zones as $zone) {
			$zone_ids[$zone['zone_id']] = $zone;
		}

		if ($selected === '' && !in_array(false, $shared, true)) {
			if ($bryansk && $config_zone_id === $bryansk['zone_id']) {
				$selected = 'bryansk';
			} elseif ($moscow && $config_zone_id === $moscow['zone_id']) {
				$selected = 'moscow';
			} elseif (isset($zone_ids[$config_zone_id])) {
				$selected = 'russia';
			}
		}

		if (!isset($zone_ids[$saved_zone_id])) {
			$saved_zone_id = 0;
		}

		$display_zone_id = ($selected === 'russia' || !isset($zone_ids[$saved_zone_id])) ? 0 : $saved_zone_id;
		$active = $shared;

		return [
			'active' => $active,
			'selected' => $selected,
			'zone_id' => $display_zone_id,
			'zones' => $zones,
			'preset_zone_ids' => [
				'bryansk' => $bryansk['zone_id'] ?? 0,
				'moscow' => $moscow['zone_id'] ?? 0
			]
		];
	}

	private function fillRussianMeta(int $language_id): void
	{
		if (!$language_id) {
			return;
		}

		$this->load->model('setting/setting');
		$this->load->model('localisation/language');

		$description = $this->readConfigDescription();
		$source_language_id = $this->storeLanguageId($language_id);

		if (!$source_language_id) {
			return;
		}

		$source = $this->metaForLanguage($description, $source_language_id);
		$current = [];

		if (isset($description[$language_id]) && is_array($description[$language_id])) {
			$current = $description[$language_id];
		}

		$changed = !isset($description[$language_id]) || !is_array($description[$language_id]);

		foreach (['meta_title', 'meta_description', 'meta_keyword'] as $key) {
			$target = trim((string)($current[$key] ?? ''));
			$value = trim((string)($source[$key] ?? ''));

			if ($target === '' && $value !== '') {
				$current[$key] = $value;
				$changed = true;
			}
		}

		if (!$changed) {
			return;
		}

		$description[$language_id] = [
			'meta_title' => (string)($current['meta_title'] ?? ''),
			'meta_description' => (string)($current['meta_description'] ?? ''),
			'meta_keyword' => (string)($current['meta_keyword'] ?? '')
		];

		$this->writeConfigValue('config_description', $description);
	}

	/**
	 * @return array<int|string, mixed>
	 */
	private function readConfigDescription(): array
	{
		$raw = $this->model_setting_setting->getValue('config_description', 0);

		if ($raw === '') {
			return [];
		}

		$decoded = json_decode($raw, true);

		return is_array($decoded) ? $decoded : [];
	}

	private function storeLanguageId(int $except_language_id): int
	{
		$code = trim((string)$this->config->get('config_language_catalog'));

		if ($code === '' || $code === 'ru-ru') {
			$code = trim((string)$this->config->get('config_language'));
		}

		if ($code === '' || $code === 'ru-ru') {
			return 0;
		}

		$language_info = $this->model_localisation_language->getLanguageByCode($code);

		if (!$language_info || (int)$language_info['language_id'] === $except_language_id) {
			return 0;
		}

		return (int)$language_info['language_id'];
	}

	/**
	 * @param array<int|string, mixed> $description
	 *
	 * @return array{meta_title: string, meta_description: string, meta_keyword: string}
	 */
	private function metaForLanguage(array $description, int $language_id): array
	{
		$row = [];

		if (isset($description[$language_id]) && is_array($description[$language_id])) {
			$row = $description[$language_id];
		}

		$meta = [
			'meta_title' => trim((string)($row['meta_title'] ?? '')),
			'meta_description' => trim((string)($row['meta_description'] ?? '')),
			'meta_keyword' => trim((string)($row['meta_keyword'] ?? ''))
		];

		if ($meta['meta_title'] === '') {
			$meta['meta_title'] = trim((string)$this->model_setting_setting->getValue('config_meta_title', 0));
		}

		if ($meta['meta_description'] === '') {
			$meta['meta_description'] = trim((string)$this->model_setting_setting->getValue('config_meta_description', 0));
		}

		if ($meta['meta_keyword'] === '') {
			$meta['meta_keyword'] = trim((string)$this->model_setting_setting->getValue('config_meta_keyword', 0));
		}

		return $meta;
	}

	/**
	 * Same rows as Setting::editSetting(), without the model proxy.
	 * editSetting() fires model/setting/setting/editSetting/after, and that event
	 * refreshes rates from the currency engine on every call.
	 *
	 * @param array<string, mixed> $setting
	 */
	private function saveLanguageSetting(array $setting): void
	{
		$code = 'language_russian';

		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `code` = '" . $this->db->escape($code) . "'");

		foreach ($setting as $key => $value) {
			if (!str_starts_with((string)$key, $code)) {
				continue;
			}

			$stored = is_array($value) ? (string)json_encode($value) : (string)$value;

			$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = '" . $this->db->escape($code) . "', `key` = '" . $this->db->escape((string)$key) . "', `value` = '" . $this->db->escape($stored) . "', `serialized` = '" . (int)is_array($value) . "'");
		}
	}

	/**
	 * @param array<mixed>|string $value
	 */
	private function writeConfigValue(string $key, $value): void
	{
		$this->load->model('setting/setting');

		$query = $this->db->query("SELECT `setting_id` FROM `" . DB_PREFIX . "setting` WHERE `store_id` = '0' AND `code` = 'config' AND `key` = '" . $this->db->escape($key) . "' LIMIT 1");

		if ($query->num_rows) {
			$this->model_setting_setting->editValue('config', $key, $value, 0);

			return;
		}

		$stored = is_array($value) ? (string)json_encode($value) : (string)$value;

		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'config', `key` = '" . $this->db->escape($key) . "', `value` = '" . $this->db->escape($stored) . "', `serialized` = '" . (int)is_array($value) . "'");
	}

	/**
	 * @return array{version: string, url: string, kind: string, ref: string}|null
	 */
	private function latestGithubRelease(string $repo): ?array
	{
		$release = $this->githubRelease($repo);
		$tag = $this->githubBestTag($repo);

		if ($release === null && $tag === null) {
			return null;
		}

		if ($release !== null && ($tag === null || $this->compareVersions($release['version'], $tag['version']) >= 0)) {
			return $release;
		}

		return $tag;
	}

	/**
	 * @return array{version: string, url: string, kind: string, ref: string}|null
	 */
	private function githubRelease(string $repo): ?array
	{
		$response = $this->githubGet('https://api.github.com/repos/' . $repo . '/releases/latest', $repo);

		if ($response['status'] === 404) {
			return null;
		}

		if ($response['status'] !== 200 || !is_array($response['body'])) {
			return null;
		}

		$ref = trim((string)($response['body']['tag_name'] ?? ''));
		$version = $this->plainVersion($ref);

		if ($version === '' || !$this->githubRefAllowed($ref)) {
			return null;
		}

		$url = trim((string)($response['body']['html_url'] ?? ''));

		if ($url === '') {
			$url = 'https://github.com/' . $repo . '/releases/tag/' . rawurlencode($ref);
		}

		return [
			'version' => $version,
			'url' => $url,
			'kind' => 'release',
			'ref' => $ref
		];
	}

	/**
	 * @return array{version: string, url: string, kind: string, ref: string}|null
	 */
	private function githubBestTag(string $repo): ?array
	{
		$url = 'https://api.github.com/repos/' . $repo . '/tags?per_page=30';
		$best = '';
		$best_name = '';
		$ok = false;

		for ($page = 0; $page < 5 && $url !== ''; $page++) {
			$response = $this->githubGet($url, $repo);

			if ($response['status'] !== 200 || !is_array($response['body'])) {
				return $ok ? $this->tagResult($repo, $best, $best_name) : null;
			}

			$ok = true;
			$count = 0;

			foreach ($response['body'] as $tag) {
				if (!is_array($tag)) {
					continue;
				}

				$count++;
				$name = trim((string)($tag['name'] ?? ''));
				$version = $this->plainVersion($name);

				if ($version === '') {
					continue;
				}

				if ($best === '' || $this->compareVersions($version, $best) > 0) {
					$best = $version;
					$best_name = $name;
				}
			}

			$next = (string)($response['next'] ?? '');

			if ($next === '' || $count < 30) {
				break;
			}

			$url = $next;
		}

		return $this->tagResult($repo, $best, $best_name);
	}

	/**
	 * @return array{version: string, url: string, kind: string, ref: string}|null
	 */
	private function tagResult(string $repo, string $version, string $name): ?array
	{
		$tag = $name !== '' ? $name : $version;

		if ($version === '' || !$this->githubRefAllowed($tag)) {
			return null;
		}

		return [
			'version' => $version,
			'url' => 'https://github.com/' . $repo . '/releases/tag/' . rawurlencode($tag),
			'kind' => 'tag',
			'ref' => $tag
		];
	}

	/**
	 * @return array{status: int, body: array<mixed>|null, next: string}
	 */
	private function githubGet(string $url, string $repo, int $timeout = 5): array
	{
		$current = $url;

		for ($hop = 0; $hop < 3; $hop++) {
			if (!$this->githubApiUrlAllowed($current, $repo)) {
				return ['status' => 0, 'body' => null, 'next' => ''];
			}

			$curl = curl_init();

			curl_setopt_array($curl, [
				CURLOPT_URL => $current,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HEADER => true,
				CURLOPT_CONNECTTIMEOUT => 5,
				CURLOPT_TIMEOUT => $timeout,
				CURLOPT_USERAGENT => 'ocn-language-russian',
				CURLOPT_HTTPHEADER => ['Accept: application/vnd.github+json'],
				CURLOPT_FOLLOWLOCATION => false,
				CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
				CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS
			]);

			$body = curl_exec($curl);
			$status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
			$header_size = (int)curl_getinfo($curl, CURLINFO_HEADER_SIZE);
			$error = curl_errno($curl);
			curl_close($curl);

			if ($body === false || $error) {
				return ['status' => 0, 'body' => null, 'next' => ''];
			}

			$headers = substr((string)$body, 0, $header_size);
			$payload = substr((string)$body, $header_size);

			if (in_array($status, [301, 302, 303, 307, 308], true)) {
				$location = $this->headerLocation($headers);

				if ($location === '') {
					return ['status' => 0, 'body' => null, 'next' => ''];
				}

				$current = $this->absoluteUrl($current, $location);
				continue;
			}

			$decoded = json_decode($payload, true);

			return [
				'status' => $status,
				'body' => is_array($decoded) ? $decoded : null,
				'next' => $this->githubNextLink($headers)
			];
		}

		return ['status' => 0, 'body' => null, 'next' => ''];
	}

	private function githubNextLink(string $headers): string
	{
		if (!preg_match_all('/^Link:\s*(.+)$/mi', $headers, $lines) || !$lines[1]) {
			return '';
		}

		$links = $lines[1];
		$line = (string)end($links);

		if (!preg_match('/<([^>]+)>;\s*rel="next"/', $line, $match)) {
			return '';
		}

		return $match[1];
	}

	private function plainVersion(string $version): string
	{
		$version = trim($version);

		if (str_starts_with(strtolower($version), 'v')) {
			$version = substr($version, 1);
		}

		return trim($version);
	}

	private function compareVersions(string $left, string $right): int
	{
		$a = $this->versionParts($left);
		$b = $this->versionParts($right);
		$length = max(count($a['numbers']), count($b['numbers']));

		for ($i = 0; $i < $length; $i++) {
			$av = $a['numbers'][$i] ?? 0;
			$bv = $b['numbers'][$i] ?? 0;

			if ($av !== $bv) {
				return $av <=> $bv;
			}
		}

		return $a['re'] <=> $b['re'];
	}

	/**
	 * @return array{numbers: array<int, int>, re: int}
	 */
	private function versionParts(string $version): array
	{
		$version = $this->plainVersion($version);
		$re = 0;

		if (preg_match('/\.RE(\d+)$/i', $version, $match)) {
			$re = (int)$match[1];
			$version = substr($version, 0, -strlen($match[0]));
		}

		$numbers = [];

		foreach (explode('.', $version) as $part) {
			$numbers[] = (int)$part;
		}

		return ['numbers' => $numbers, 're' => $re];
	}

	private function extensionVersion(): string
	{
		return trim((string)($this->extensionInstall()['version'] ?? ''));
	}

	/**
	 * @return array{repository: string, forum: string, site: string}
	 */
	private function githubRepo(): ?string
	{
		$link = trim((string)($this->extensionInstall()['link'] ?? ''));
		$parts = parse_url($link);

		if (!is_array($parts)) {
			return null;
		}

		$host = strtolower((string)($parts['host'] ?? ''));

		if ($host !== 'github.com' && $host !== 'www.github.com') {
			return null;
		}

		$path = trim((string)($parts['path'] ?? ''), '/');
		$path = preg_replace('/\.git$/', '', $path) ?? '';

		if (!preg_match('#^([^/]+)/([^/]+)$#', $path, $match)) {
			return null;
		}

		if ($match[1] === '' || $match[2] === '') {
			return null;
		}

		return $match[1] . '/' . $match[2];
	}

	/**
	 * @return array{repository: string, forum: string, site: string}
	 */
	private function extensionLinks(): array
	{
		return [
			'repository' => trim((string)($this->extensionInstall()['link'] ?? '')),
			'forum' => 'https://forum.opencart.name/resources/Русский-язык-для-opencart-4.131/',
			'site' => 'https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=39070'
		];
	}

	/**
	 * @return array<string, mixed>
	 */
	private function extensionInstall(): array
	{
		$file = DIR_EXTENSION . 'ocn_language_russian/install.json';

		if (!is_file($file)) {
			return [];
		}

		$install = json_decode((string)file_get_contents($file), true);

		return is_array($install) ? $install : [];
	}

	/**
	 * @return array{error: string, newer: bool, repo: string, ref: string, remote: array{version: string, url: string, kind: string, ref: string}|null, changed: array<int, string>, added: array<int, string>, removed: array<int, string>, remote_files: array<string, string>, remote_sizes: array<string, int>}
	 */
	private function packageDiff(): array
	{
		$result = [
			'error' => '',
			'newer' => false,
			'repo' => '',
			'ref' => '',
			'remote' => null,
			'changed' => [],
			'added' => [],
			'removed' => [],
			'remote_files' => [],
			'remote_sizes' => []
		];

		$repo = $this->githubRepo();

		if ($repo === null || !$this->repoAllowed($repo)) {
			$result['error'] = $this->language->get('error_update_link');

			return $result;
		}

		$result['repo'] = $repo;
		$remote = $this->latestGithubRelease($repo);

		if ($remote === null || empty($remote['ref'])) {
			$result['error'] = $this->language->get('error_update');

			return $result;
		}

		$result['remote'] = $remote;
		$result['ref'] = $remote['ref'];

		if ($this->compareVersions($remote['version'], $this->extensionVersion()) <= 0) {
			return $result;
		}

		$result['newer'] = true;
		$root = $this->extensionRoot();

		if ($root === '') {
			$result['error'] = $this->language->get('error_update_files');

			return $result;
		}

		$remote_package = $this->remotePackageFiles($repo, $remote['ref']);

		if ($remote_package === null) {
			$result['error'] = $this->language->get('error_update_files');

			return $result;
		}

		$local_files = $this->localPackageFiles($root);

		if ($local_files === null) {
			$result['error'] = $this->language->get('error_update_files');

			return $result;
		}

		foreach ($remote_package['files'] as $path => $sha) {
			if (!isset($local_files[$path])) {
				$result['added'][] = $path;
			} elseif (!hash_equals($local_files[$path], $sha)) {
				$result['changed'][] = $path;
			}
		}

		foreach ($local_files as $path => $sha) {
			if (!isset($remote_package['files'][$path])) {
				$result['removed'][] = $path;
			}
		}

		sort($result['changed']);
		sort($result['added']);
		sort($result['removed']);

		$result['remote_files'] = $remote_package['files'];
		$result['remote_sizes'] = $remote_package['sizes'];

		return $result;
	}

	/**
	 * @param array{changed: array<int, string>, added: array<int, string>, removed: array<int, string>, remote_files: array<string, string>, remote_sizes: array<string, int>, repo: string, ref: string} $diff
	 *
	 * @return array{error: string}
	 */
	private function applyPackageDiff(array $diff): array
	{
		$root = $this->extensionRoot();

		if ($root === '' || !$this->repoAllowed($diff['repo']) || !$this->githubRefAllowed($diff['ref'])) {
			return ['error' => $this->language->get('error_upgrade')];
		}

		$temp = $this->updateTempDirectory();

		if ($temp === '') {
			return ['error' => $this->language->get('error_upgrade')];
		}

		$downloads = array_merge($diff['changed'], $diff['added']);

		try {
			foreach ($downloads as $relative) {
				if (!isset($diff['remote_files'][$relative], $diff['remote_sizes'][$relative])) {
					return ['error' => $this->language->get('error_upgrade')];
				}

				$binary = $this->downloadPackageFile($diff['repo'], $diff['ref'], $relative);

				if ($binary === null || strlen($binary) !== $diff['remote_sizes'][$relative]) {
					return ['error' => $this->language->get('error_upgrade')];
				}

				$sha = sha1('blob ' . strlen($binary) . "\0" . $binary);

				if (!hash_equals($diff['remote_files'][$relative], $sha) || !$this->writeTempFile($temp, $relative, $binary)) {
					return ['error' => $this->language->get('error_upgrade')];
				}
			}

			$twig = false;

			foreach ($downloads as $relative) {
				$binary = file_get_contents($temp . $relative);

				if ($binary === false || !$this->writeExtensionFile($root, $relative, $binary)) {
					return ['error' => $this->language->get('error_upgrade_write')];
				}

				if (str_ends_with(strtolower($relative), '.twig')) {
					$twig = true;
				}
			}

			foreach ($diff['removed'] as $relative) {
				if (!$this->deleteExtensionFile($root, $relative)) {
					return ['error' => $this->language->get('error_upgrade_write')];
				}

				if (str_ends_with(strtolower($relative), '.twig')) {
					$twig = true;
				}
			}

			$this->pruneEmptyDirectories($root);

			if ($twig) {
				$this->clearTemplateCache();
			}

			return ['error' => ''];
		} finally {
			$this->removeDirectory($temp);
		}
	}

	/**
	 * @return array{files: array<string, string>, sizes: array<string, int>}|null
	 */
	private function remotePackageFiles(string $repo, string $ref): ?array
	{
		if (!$this->githubRefAllowed($ref) || !$this->repoAllowed($repo)) {
			return null;
		}

		$url = 'https://api.github.com/repos/' . $repo . '/git/trees/' . rawurlencode($ref) . '?recursive=1';
		$response = $this->githubGet($url, $repo, 15);

		if ($response['status'] !== 200 || !is_array($response['body'])) {
			return null;
		}

		if (!empty($response['body']['truncated']) || !isset($response['body']['tree']) || !is_array($response['body']['tree'])) {
			return null;
		}

		$prefix = $this->packagePrefix();
		$files = [];
		$sizes = [];

		foreach ($response['body']['tree'] as $item) {
			if (!is_array($item) || ($item['type'] ?? '') !== 'blob') {
				continue;
			}

			$path = str_replace('\\', '/', (string)($item['path'] ?? ''));

			if (!str_starts_with($path, $prefix)) {
				continue;
			}

			$relative = substr($path, strlen($prefix));
			$sha = strtolower((string)($item['sha'] ?? ''));
			$size = (int)($item['size'] ?? -1);

			if (!$this->safeRelativePath($relative) || !preg_match('/^[a-f0-9]{40}$/', $sha) || $size < 0 || $size > 2097152) {
				return null;
			}

			$files[$relative] = $sha;
			$sizes[$relative] = $size;
		}

		if (!isset($files['install.json'])) {
			return null;
		}

		return ['files' => $files, 'sizes' => $sizes];
	}

	/**
	 * @return array<string, string>|null
	 */
	private function localPackageFiles(string $root): ?array
	{
		try {
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
			);
		} catch (\UnexpectedValueException $exception) {
			return null;
		}

		$files = [];

		foreach ($iterator as $file) {
			if (!$file instanceof \SplFileInfo || $file->isLink() || !$file->isFile()) {
				continue;
			}

			$real = $file->getRealPath();

			if ($real === false) {
				return null;
			}

			$real = str_replace('\\', '/', $real);

			if (!str_starts_with($real, $root)) {
				return null;
			}

			$relative = substr($real, strlen($root));

			if (!$this->safeRelativePath($relative)) {
				return null;
			}

			$content = file_get_contents($real);

			if ($content === false) {
				return null;
			}

			$files[$relative] = sha1('blob ' . strlen($content) . "\0" . $content);
		}

		return $files;
	}

	private function downloadPackageFile(string $repo, string $ref, string $relative): ?string
	{
		$url = $this->packageFileUrl($repo, $ref, $relative);

		if ($url === '') {
			return null;
		}

		return $this->httpGetBinary($url, $repo);
	}

	private function packageFileUrl(string $repo, string $ref, string $relative): string
	{
		if (!$this->githubRefAllowed($ref) || !$this->safeRelativePath($relative) || !$this->repoAllowed($repo)) {
			return '';
		}

		$encoded = implode('/', array_map('rawurlencode', explode('/', $relative)));
		$url = 'https://raw.githubusercontent.com/' . $repo . '/' . rawurlencode($ref) . '/' . $this->packagePrefix() . $encoded;

		return $this->rawUrlAllowed($url, $repo) ? $url : '';
	}

	private function httpGetBinary(string $url, string $repo): ?string
	{
		$current = $url;

		for ($hop = 0; $hop < 3; $hop++) {
			if (!$this->rawUrlAllowed($current, $repo)) {
				return null;
			}

			$curl = curl_init();

			curl_setopt_array($curl, [
				CURLOPT_URL => $current,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_HEADER => true,
				CURLOPT_FOLLOWLOCATION => false,
				CURLOPT_CONNECTTIMEOUT => 5,
				CURLOPT_TIMEOUT => 15,
				CURLOPT_USERAGENT => 'ocn-language-russian',
				CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
				CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS
			]);

			$body = curl_exec($curl);
			$status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
			$header_size = (int)curl_getinfo($curl, CURLINFO_HEADER_SIZE);
			$error = curl_errno($curl);
			curl_close($curl);

			if ($body === false || $error) {
				return null;
			}

			$headers = substr((string)$body, 0, $header_size);
			$payload = substr((string)$body, $header_size);

			if (in_array($status, [301, 302, 303, 307, 308], true)) {
				$location = $this->headerLocation($headers);

				if ($location === '') {
					return null;
				}

				$current = $this->absoluteUrl($current, $location);
				continue;
			}

			if ($status !== 200) {
				return null;
			}

			return $payload;
		}

		return null;
	}

	private function writeTempFile(string $temp, string $relative, string $content): bool
	{
		if (!$this->safeRelativePath($relative)) {
			return false;
		}

		$target = $temp . $relative;

		if (!$this->makeDirectory($temp, dirname($target)) || is_link($target)) {
			return false;
		}

		if (file_put_contents($target, $content) === false) {
			return false;
		}

		$real = realpath($target);

		if ($real === false) {
			return false;
		}

		return str_starts_with(str_replace('\\', '/', $real), $temp);
	}

	private function writeExtensionFile(string $root, string $relative, string $content): bool
	{
		if (!$this->safeRelativePath($relative) || $this->pathHasLink($root, $relative)) {
			return false;
		}

		$target = $root . $relative;

		if (!$this->makeDirectory($root, dirname($target)) || is_link($target)) {
			return false;
		}

		if (file_put_contents($target, $content) === false) {
			return false;
		}

		$real = realpath($target);

		if ($real === false) {
			return false;
		}

		$real = str_replace('\\', '/', $real);

		return str_starts_with($real, $root) && $real !== rtrim($root, '/');
	}

	private function deleteExtensionFile(string $root, string $relative): bool
	{
		if (!$this->safeRelativePath($relative) || $this->pathHasLink($root, $relative)) {
			return false;
		}

		$target = $root . $relative;

		if (!file_exists($target)) {
			return true;
		}

		if (is_link($target) || !is_file($target)) {
			return false;
		}

		$real = realpath($target);

		if ($real === false) {
			return false;
		}

		$real = str_replace('\\', '/', $real);

		if ($real === rtrim($root, '/') || !str_starts_with($real, $root)) {
			return false;
		}

		return unlink($real);
	}

	private function makeDirectory(string $root, string $directory): bool
	{
		$root = rtrim(str_replace('\\', '/', $root), '/') . '/';
		$directory = rtrim(str_replace('\\', '/', $directory), '/') . '/';

		if (!str_starts_with($directory, $root)) {
			return false;
		}

		$relative = trim(substr($directory, strlen($root)), '/');

		if ($relative === '') {
			return is_dir(rtrim($root, '/'));
		}

		if (!$this->safeRelativePath($relative)) {
			return false;
		}

		$cursor = rtrim($root, '/');

		foreach (explode('/', $relative) as $part) {
			$cursor .= '/' . $part;

			if (is_link($cursor)) {
				return false;
			}

			if (is_dir($cursor)) {
				continue;
			}

			if (file_exists($cursor) || !mkdir($cursor, 0777)) {
				return false;
			}
		}

		$real = realpath(rtrim($directory, '/'));

		if ($real === false) {
			return false;
		}

		$real = rtrim(str_replace('\\', '/', $real), '/') . '/';

		return str_starts_with($real, $root);
	}

	private function pathHasLink(string $root, string $relative): bool
	{
		$cursor = rtrim(str_replace('\\', '/', $root), '/');

		foreach (explode('/', $relative) as $part) {
			$cursor .= '/' . $part;

			if (is_link($cursor)) {
				return true;
			}

			if (!file_exists($cursor)) {
				return false;
			}
		}

		return false;
	}

	private function safeRelativePath(string $path): bool
	{
		if ($path === '' || str_contains($path, "\0") || str_contains($path, '\\') || str_contains($path, ':')) {
			return false;
		}

		if (str_starts_with($path, '/')) {
			return false;
		}

		foreach (explode('/', $path) as $part) {
			if ($part === '' || $part === '.' || $part === '..') {
				return false;
			}
		}

		return true;
	}

	private function extensionRoot(): string
	{
		$real = realpath(DIR_EXTENSION . 'ocn_language_russian');

		if ($real === false || !is_dir($real)) {
			return '';
		}

		return rtrim(str_replace('\\', '/', $real), '/') . '/';
	}

	private function packagePrefix(): string
	{
		return 'ocn_language_russian.ocmod/';
	}

	private function githubRefAllowed(string $ref): bool
	{
		return $ref !== '' && (bool)preg_match('/^[A-Za-z0-9._-]{1,128}$/', $ref);
	}

	private function repoAllowed(string $repo): bool
	{
		return (bool)preg_match('#^[^/]+/[^/]+$#', $repo) && !str_contains($repo, '..') && !str_contains($repo, '\\') && !str_contains($repo, ':');
	}

	private function githubApiUrlAllowed(string $url, string $repo): bool
	{
		return $this->hostUrlAllowed($url, 'api.github.com', '/repos/' . $repo . '/');
	}

	private function rawUrlAllowed(string $url, string $repo): bool
	{
		if (!$this->hostUrlAllowed($url, 'raw.githubusercontent.com', '/' . $repo . '/')) {
			return false;
		}

		$path = (string)(parse_url($url)['path'] ?? '');

		return str_contains($path, '/' . trim($this->packagePrefix(), '/') . '/');
	}

	private function hostUrlAllowed(string $url, string $host, string $path_prefix): bool
	{
		if (preg_match('/[\s\x00-\x1F]/', $url) || str_contains($url, '\\')) {
			return false;
		}

		$parts = parse_url($url);

		if (!is_array($parts) || isset($parts['user']) || isset($parts['pass']) || isset($parts['port']) || isset($parts['fragment'])) {
			return false;
		}

		$scheme = strtolower((string)($parts['scheme'] ?? ''));
		$url_host = strtolower((string)($parts['host'] ?? ''));
		$path = (string)($parts['path'] ?? '');

		if ($scheme !== 'https' || $url_host !== $host) {
			return false;
		}

		return str_starts_with($path, $path_prefix) && !str_contains($path, '/../');
	}

	private function headerLocation(string $headers): string
	{
		if (!preg_match('/^Location:\s*(\S+)/mi', $headers, $match)) {
			return '';
		}

		return trim($match[1]);
	}

	private function absoluteUrl(string $base, string $location): string
	{
		if (preg_match('#^https://#i', $location)) {
			return $location;
		}

		$parts = parse_url($base);

		if (!is_array($parts) || !isset($parts['scheme'], $parts['host'])) {
			return '';
		}

		if (str_starts_with($location, '/')) {
			return strtolower((string)$parts['scheme']) . '://' . $parts['host'] . $location;
		}

		$path = (string)($parts['path'] ?? '/');
		$dir = rtrim(str_replace('\\', '/', dirname($path)), '/');

		return strtolower((string)$parts['scheme']) . '://' . $parts['host'] . $dir . '/' . $location;
	}

	private function updateTempDirectory(): string
	{
		$cache = realpath(DIR_CACHE);

		if ($cache === false || !is_dir($cache)) {
			return '';
		}

		$cache = rtrim(str_replace('\\', '/', $cache), '/') . '/';
		$path = $cache . 'ocn_language_update_' . bin2hex(random_bytes(8));

		if (!mkdir($path, 0777)) {
			return '';
		}

		$real = realpath($path);

		if ($real === false) {
			return '';
		}

		$real = rtrim(str_replace('\\', '/', $real), '/') . '/';

		if (!str_starts_with($real, $cache) || !str_contains($real, 'ocn_language_update_')) {
			return '';
		}

		return $real;
	}

	private function removeDirectory(string $directory): void
	{
		if ($directory === '' || !is_dir($directory)) {
			return;
		}

		$real = realpath($directory);
		$cache = realpath(DIR_CACHE);

		if ($real === false || $cache === false) {
			return;
		}

		$real = rtrim(str_replace('\\', '/', $real), '/');
		$cache = rtrim(str_replace('\\', '/', $cache), '/') . '/';

		if (!str_starts_with($real . '/', $cache) || !str_contains($real, 'ocn_language_update_')) {
			return;
		}

		try {
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator($real, \FilesystemIterator::SKIP_DOTS),
				\RecursiveIteratorIterator::CHILD_FIRST
			);
		} catch (\UnexpectedValueException $exception) {
			return;
		}

		foreach ($iterator as $item) {
			if ($item->isLink() || !$item->isDir()) {
				unlink($item->getPathname());
			} else {
				rmdir($item->getPathname());
			}
		}

		rmdir($real);
	}

	private function pruneEmptyDirectories(string $root): void
	{
		try {
			$iterator = new \RecursiveIteratorIterator(
				new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
				\RecursiveIteratorIterator::CHILD_FIRST
			);
		} catch (\UnexpectedValueException $exception) {
			return;
		}

		foreach ($iterator as $item) {
			if (!$item->isDir() || $item->isLink()) {
				continue;
			}

			$real = $item->getRealPath();

			if ($real === false) {
				continue;
			}

			$real = rtrim(str_replace('\\', '/', $real), '/') . '/';

			if ($real === $root || !str_starts_with($real, $root)) {
				continue;
			}

			$entries = scandir($real);

			if ($entries !== false && count($entries) === 2) {
				rmdir(rtrim($real, '/'));
			}
		}
	}

	private function clearTemplateCache(): void
	{
		$directories = glob(DIR_CACHE . 'template/*', GLOB_ONLYDIR);

		if (!$directories) {
			return;
		}

		foreach ($directories as $directory) {
			$files = glob($directory . '/*');

			if ($files) {
				foreach ($files as $file) {
					if (is_file($file)) {
						unlink($file);
					}
				}
			}

			if (is_dir($directory)) {
				rmdir($directory);
			}
		}
	}
}
